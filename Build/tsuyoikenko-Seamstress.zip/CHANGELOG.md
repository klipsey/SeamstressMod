# 0.2.9

- No model yet. I've been sick and working on smaller stuff
- Nerfed dash to always be tied to cooldown (0.5 seconds)
- Time it take to pick up Scissors increased to 5 seconds
- Scissors now form a pickup circle after 5 seconds
- Scissors now pickup if youre in the circle when it activates (no more having to leave and enter it)
- Networked the pickup circle (THE VANILLA IMPSPIKE ISNT NETWORKED?????)
- Buffed lifesteal during insatiable
- Logbook added

# 0.2.8

- Fixed NRE's happening on other survivors
- Fixed grabbing certain enemies

# 0.2.7

- Fixed railgunner mines breaking

# 0.2.6

- Networked!
- Only thing I didn't network are the circles for scissors on connecting players cause I didn't care enough
- Enjoy multiplayer! and report if anything breaks ty

# 0.2.5

- bug fixes
- rewording
- new effects
- unlock condition
- new vfx
- half networked
- fixed blink randomly breaking
- fixed damage being multiplied with scissors when thrown
- removed herobrine

# 0.2.4

- April Fools

# 0.2.3

- Added all icons

# 0.2.2

- Icons
- Wording

# 0.2.1

- Fixed hopoo feather interaction to not just spam needles and fly
- Fixed crash during load? -report if it still happens
- Renamed Imp Gauge to It Hungers
- Renamed Primal Instincts to Imp Touched Heart

# 0.2.0

- Full Rework
- No Networking

# 0.1.10

- Flurry is stronger but slower
- NETWORKING FIXED AGAIN
- Needles no longer auto fire. Git gud.

# 0.1.9

- Ability slot locations changed to make more sense.
- Added Glimpse of Purity.
- Slower swing speed on both primaries
- Probably other stuff?

# 0.1.7

- Alt special added
- Woven Fate has a 2 second grace period for recasting if you are on the ground

# 0.1.6

- Tweaks

# 0.1.5

- Massive fundemental kit changes
- Butchered no longer grants attackspeed
- Butchered no longer empowers abilites
- Butchered now grants Cut on all abilities
- Cut changed to -> Reduces your secondary's cooldown on hit. Apply a bleed based on enemies missing health
- Stitch changed to -> Deal damage to tear open Stitches and apply cut
- Trimming Slashes changed to -> Slash in front for damage. Every third hit applies Stitches and deals bonus damage
- Unrelenting Flurry changed to -> Slash in front for damage. Heal for 10% of damage dealt
- Removed Planar Shift
- Woven Fate changed to -> Leap in a direction dealing damage. Recast in the air to dash dealing damage to enemies. Both casts apply Stitches
- Removed Bloodsoaked Path
- Added Planar Shift -> 50% HP. Blink in a direction dealing massive damage applying Sitches at the destination. Gain Butchered. While Butchered Planar Shift becomes Expunge
- Threaded Volley stock is now your needle count
- Threaded Volley cooldown lowered to 7.5 seconds
- Threaded Volley does not fire all Needles. Hold down the button for the amount of Needles you would like to fire.
- Needles do not apply Stitches anymore.
- Still works in multiplayer
- Bugs

# 0.1.4

- Might be multiplayer compatible now
- Reworked alt abilities a tad
- Removed UI. This may be added back in final version
- Bugs

# 0.1.3

- Added alt abilites and stuff
- Bugs
- DO NOT PLAY MULTIPLAYER. IT'S PROBABLY IN THE WORST STATE EVER AS OF NOW.

# 0.1.2

- Expunge visuals reworked
- Expunge damage amount above crosshair
- Mods that affect buff duration should not effect needle recharge speed
- Butchered SFX is a bit more clear on when it ends

# 0.1.1

- Bugfixes and text cleanup
- Needles only home after the first hit
- Expunge damage has a flat base of 100%
- Expunge can potentially proc bands at higher healing values

# 0.1.0

- Hopefully, the final base kit.
- Regenerate Needles overtime. Gain additiojnalo Needles when Sttiches are torn by Cut or when enemies with Cuts die.
- Stitch changed to Apply Stitches. Applying Stitches and tearing open Stitches reduce cooldowns by 0.25 seconds.
- Cut changed to Tear open Stitches dealing damage based on enemies missing health and apply Cuts. Cuts deal a percentage of enemies missing health per second for 5 seconds
- Changed all ability names to be more interesting
- Trim changed to 2nd hit applies stitch. 3rd hit applies Cut. while Butchered all hits apply Stitch

# 0.0.9

- missed crucial changes in text

# 0.0.8

- Stitch changed to "Deal 100% damage. Apply Stitched which deals 0.5% (0.25% against bosses) of the enemies missing health over 4 seconds".
- Cut changed to "Consume Stitch dealing 2% of the enemies missing health per Stitched. Lower cooldowns by 1 seconds per Stitched consumed".
  - Note: Enemies killed with stitched will give you the cooldown you should have gotten.
- Added gain a needle on cut to passive.
- Changed Trim butchered effect to gain Stitch on the first and second strike. Third strike additionally Cuts.
- Weave loses speed on hit for sticking power.
- Expunge has cut.
- Sew text moved to Needle Keyword
- Cooldowns hopefully adjusted enough???
- Needle HUD no longer persists between character
- idk probably some other stuff I forgot

# 0.0.7

- Added Stitch. Stitch deals missing hp damage over time and lower cooldowns by 0.5 seconds on hit.
  - Changed Needle damage to Stitch damage.
  - Changed Trim final hit to Stitch damage.
- Changed Cut to additionally give Needles on hit
- Changed Trim butchered effect to gain Cut on the first and second strike
- Changed Weave butchered effect to 20% life steal
- Expunge works now...
- Nerfed Needle damage to 50% and buffed healing to 50%
- Added Needle count to crosshair as a new UI
- idk probably some other stuff I forgot
