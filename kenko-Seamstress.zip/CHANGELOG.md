# 0.1.0
- Hopefully, the final base kit.
- Regenerate Needles overtime. Gain additiojnalo Needles when Sttiches are torn by Cut or when enemies with Cuts die.
- Stitch changed to Apply Stitches. Applying Stitches and tearing open Stitches reduce cooldowns by 0.25 seconds.
- Cut changed to Tear open Stitches dealing damage based on enemies missing health and apply Cuts. Cuts deal a percentage of enemies missing health per second for 5 seconds
- Changed all ability names to be more interesting
- Trim changed to 2nd hit applies stitch. 3rd hit applies Cut. while Butchered all hits apply Stitch
# 0.0.9
- missed crucial changes in text
# 0.0.8
- Stitch changed to "Deal 100% damage. Apply Stitched which deals 0.5% (0.25% against bosses) of the enemies missing health over 4 seconds".
- Cut changed to "Consume Stitch dealing 2% of the enemies missing health per Stitched. Lower cooldowns by 1 seconds per Stitched consumed".
    - Note: Enemies killed with stitched will give you the cooldown you should have gotten.
- Added gain a needle on cut to passive.
- Changed Trim butchered effect to gain Stitch on the first and second strike. Third strike additionally Cuts.
- Weave loses speed on hit for sticking power.
- Expunge has cut.
- Sew text moved to Needle Keyword
- Cooldowns hopefully adjusted enough???
- Needle HUD no longer persists between character
- idk probably some other stuff I forgot

# 0.0.7
- Added Stitch. Stitch deals missing hp damage over time and lower cooldowns by 0.5 seconds on hit.
    - Changed Needle damage to Stitch damage.
    - Changed Trim final hit to Stitch damage.
- Changed Cut to additionally give Needles on hit
- Changed Trim butchered effect to gain Cut on the first and second strike
- Changed Weave butchered effect to 20% life steal
- Expunge works now...
- Nerfed Needle damage to 50% and buffed healing to 50%
- Added Needle count to crosshair as a new UI
- idk probably some other stuff I forgot
