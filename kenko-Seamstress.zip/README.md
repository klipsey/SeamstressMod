# Seamstress
- BETA

## Model Preview
[![](https://media.discordapp.net/attachments/1119077461783748652/1198195533337067610/image.png?ex=65be058c&is=65ab908c&hm=57c4f3666bf793cd28c0e14c9224ac68294b078be3f71d5d14c14558f466d483&=&format=webp&quality=lossless&width=470&height=670)]()

## Overview
Seamstress is a mobile survivor that uses her health for damage. She doesn't gain base damage per level so stack health items to take advantage of her passive. 

Primary: swing scissor, cut damage 5% enemy current health and gain needle on third hit, more damage during utility buff (butchered) blah blah
Trim is a consistent way to deal damage while full hp.

Secondary: dash forward regaining stock on kill and gain a needle on kill. butchered gives slayer and fully resets
Weave is a basic dash on its own but with butcher it becomes devastating in groups.

Utility: 50% current health for some speedy buffs and butchered also gain needle
Reap can give you incredible buffs through butcher but use it carefully, you could preemptively end your run.

Special: aoe damage and shoot all your needles and stuff
Reap what you.. Sew? Use Sew to fire your needles to hit enemies from afar.

Please play my mod. I need to find bugs.
Contact at discord: @tsuyoikenko